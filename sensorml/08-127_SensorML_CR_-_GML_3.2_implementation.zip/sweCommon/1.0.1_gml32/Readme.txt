OpenGIS(r) SWE Common v1.0.1 - ReadMe.txt

Sensor Web Enablement (SWE) Common data types v1.0.1.

The SWE Common schema were approved as Version 1.0.0 by the OGC membership on
23 June 2007.  They are defined in the OGC SensorML document 07-000.
Corrigendum 1 (OGC 07-122r2) made changes to these and were released as
sweCommon 1.0.1.

See ChangeLog.txt for additional details.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/policies/ .

Copyright (c) 2007 Open Geospatial Consortium, Inc. All Rights Reserved.

